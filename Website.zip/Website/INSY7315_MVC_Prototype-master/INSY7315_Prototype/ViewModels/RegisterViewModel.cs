﻿using INSY7315_Prototype.Models;
using System.ComponentModel.DataAnnotations;

namespace INSY7315_Prototype.ViewModels
{
    public class RegisterViewModel
    {
        //Used to collect information entered


        [Required(ErrorMessage = "Full name is required")]
        public string FullName { get; set; } = string.Empty;


        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; } = string.Empty;


        [Required(ErrorMessage = "Phone number is required")]
        [Phone(ErrorMessage = "Please enter valid phone number")]
        public string Phone { get; set; } = string.Empty;


        [Required(ErrorMessage = "ID number is required")]
        [RegularExpression(@"^\d{13}$",ErrorMessage = "ID number must be exactly 13 digits")]
        public string IdNumber { get; set; } = string.Empty;


        [Required(ErrorMessage = "Password is required")]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;


        [Required(ErrorMessage = "Please confirm your password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords do not match")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
