﻿namespace INSY7315_Prototype.ViewModels
{
    public class ManagerLoanApplicationViewModel
    {
        public string ApplicationId { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string  UserEmail {  get; set; } = string.Empty;
        public decimal RequestedAmount { get; set; }
        public string ReasonForLoan { get; set; } = string.Empty;
        public DateTime DateApplied { get; set; }
        public string Status {  get; set; } = string.Empty;
        public ClientDetailsViewModel ClientDetails { get; set; } = new();

    }

    public class ClientDetailsViewModel
    {
        public string FullNameAndSurname { get; set; } = string.Empty;
        public string IdNumber { get; set; } = string.Empty;
        public string CellNo { get; set; } = string.Empty;
        public string HomeTelNo { get; set; } = string.Empty;
        public string MaritalStatus { get; set; } = string.Empty;
        public string CurrentPhysicalAddress { get; set; } = string.Empty;
        public string PostalAddress { get; set; } = string.Empty;
        public string ResidenceDuration { get; set; } = string.Empty;
        public string CompanyName { get; set; } = string.Empty;
        public string Occupation { get; set; } = string.Empty;
        public string WorkTelephone { get; set; } = string.Empty;
        public string BankName { get; set; } = string.Empty;
        public string AccountType { get; set; } = string.Empty;
        public string AccountNumber { get; set; } = string.Empty;
        public string SpouseNameAndSurname { get; set; } = string.Empty;
        public string Relative1Name { get; set; } = string.Empty;
        public string Relative1TelNumber { get; set; } = string.Empty;
    }
}
